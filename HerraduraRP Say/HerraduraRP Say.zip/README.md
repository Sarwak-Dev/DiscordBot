# Say, discord bot.
#### this bot will say anything you want.
#### his prefix is "." 
## commands:
### .say [your text] // says anything you want
## .sayembed [yourtext] // says anything you want in embed

## How to make this bot work?
### its really easy. Firsty you need to download it, then go to `slappey.json` and replace `YOUR_TOKEN_HERE` with your token you can get on [Discord Developer portal][1] Now make sure you have node installed on your computer if not you can download it [here.][2] after you have node you need to open any terminal and get into the folder. On windows i like to go into that folder in File Explorer and then click on the text bot that show the location and type there `cmd` and hit enter. In cmd you just need to type `npm run dev` and it should say [your bot's name] has logged in. If it said error let me know on my [discord][3] i can help you out.

# if you want to support me
## if you want to donate you can buy me a coffee at [Buy Me A Coffee](https://www.buymeacoffee.com/p33t "Buy Me A Coffee")

# If you want to get this bot hosted for free
## you can use my free hosting at [zenet.host](https://zenet.host "zenet.host")
## Don't worry you don't need to add any payment details or something like that
Please note that we do not provide support for the bot there. We can help you install it but we will not help you add more functions to it.



[1]: https://discord.com/developers/applications "Discord Developer Portal"
[2]: https://nodejs.org/en/ "here"
[3]: https://discord.gg/p9HqGJp4mv "discord"
